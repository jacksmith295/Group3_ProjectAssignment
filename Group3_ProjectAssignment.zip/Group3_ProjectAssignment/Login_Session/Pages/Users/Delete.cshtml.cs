using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Group3_ProjectAssignment.Models;
using Group3_ProjectAssignment.Pages.DatabaseConnection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Group3_ProjectAssignment.Pages.Users
{
    public class DeleteModel : PageModel
    {
        [BindProperty]
        public List<User> UserDel { get; set; }

        [BindProperty]
        public List<bool> IsSelect { get; set; } 


        public List<User> UserToDelete { get; set; } 

        public IActionResult OnGet()
        {
            DatabaseConnect dbstring = new DatabaseConnect();
            string DbConnection = dbstring.DatabaseString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM UserTable";

                SqlDataReader reader = command.ExecuteReader();

                UserDel = new List<User>(); 
                IsSelect = new List<bool>();
                while (reader.Read())
                {
                    User rec = new User
                    {
                        Id = reader.GetInt32(0), 
                        FirstName = reader.GetString(1),
                        UserName = reader.GetString(2),
                        Password = reader.GetString(3),
                        Role = reader.GetString(4)
                    };
                    UserDel.Add(rec);
                    IsSelect.Add(false);
                }
            }


            return Page();
        }

        public IActionResult OnPost()
        {
            UserToDelete = new List<User>();
            for (int i = 0; i < UserDel.Count; i++) 
            {
                if (IsSelect[i] == true) 
                {
                    UserToDelete.Add(UserDel[i]); 
                }
            }

            Console.WriteLine("User to be deleted : ");

            for (int i = 0; i < UserToDelete.Count(); i++)
            {
                Console.WriteLine(UserToDelete[i].Id);
                Console.WriteLine(UserToDelete[i].FirstName); 
                Console.WriteLine(UserToDelete[i].UserName);
                Console.WriteLine(UserToDelete[i].Password);
                Console.WriteLine(UserToDelete[i].Role);               
            }          

            DatabaseConnect dbstring = new DatabaseConnect();
            string DbConnection = dbstring.DatabaseString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            for (int i = 0; i < UserToDelete.Count(); i++)
            {

                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = conn;
                    command.CommandText = @"DELETE FROM UserTable WHERE Id = @UserDelID";
                    command.Parameters.AddWithValue("@UserDelID", UserToDelete[i].Id);
                    command.ExecuteNonQuery();
                }
            }

            return RedirectToPage("/AdminPages/AdminIndex");
        }
    }
}
