using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Group3_ProjectAssignment.Models;
using Group3_ProjectAssignment.Pages.DatabaseConnection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Group3_ProjectAssignment.Pages.Users
{
    public class DeleteModel : PageModel
    {
        [BindProperty]
        public List<User> Mod { get; set; }

        [BindProperty]
        public List<bool> IsSelect { get; set; } 


        public List<User> ModToDelete { get; set; } 

        public IActionResult OnGet()
        {
            DatabaseConnect dbstring = new DatabaseConnect();
            string DbConnection = dbstring.DatabaseString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM UserTable";

                SqlDataReader reader = command.ExecuteReader();

                Mod = new List<User>(); 
                IsSelect = new List<bool>();
                while (reader.Read())
                {
                    User rec = new User
                    {
                        Id = reader.GetInt32(0), 
                        FirstName = reader.GetString(1),
                        UserName = reader.GetString(2),
                        Password = reader.GetString(3),
                        Role = reader.GetString(4)
                    };
                    Mod.Add(rec);
                    IsSelect.Add(false);
                }
            }


            return Page();
        }

        public IActionResult OnPost()
        {
            ModToDelete = new List<User>();
            for (int i = 0; i < Mod.Count; i++) 
            {
                if (IsSelect[i] == true) 
                {
                    ModToDelete.Add(Mod[i]); 
                }
            }

            Console.WriteLine("User to be deleted : ");

            for (int i = 0; i < ModToDelete.Count(); i++)
            {
                Console.WriteLine(ModToDelete[i].Id);
                Console.WriteLine(ModToDelete[i].FirstName); 
                Console.WriteLine(ModToDelete[i].UserName);
                Console.WriteLine(ModToDelete[i].Password);
                Console.WriteLine(ModToDelete[i].Role);               
            }          

            DatabaseConnect dbstring = new DatabaseConnect();
            string DbConnection = dbstring.DatabaseString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            for (int i = 0; i < ModToDelete.Count(); i++)
            {

                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = conn;
                    command.CommandText = @"DELETE FROM User WHERE Id = @ModID";
                    command.Parameters.AddWithValue("@ModID", ModToDelete[i].Id);
                    command.ExecuteNonQuery();
                }
            }

            return RedirectToPage("/AdminPages/AdminIndex");
        }
    }
}
