﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Group3_ProjectAssignment.Pages.DatabaseConnection
{
    public class DatabaseConnect
    {
        public string DatabaseString ()
        {
            string DbString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Jack\source\repos\Week-10-PdfExample-Solution\Login_Session\Data\UserTable.mdf;Integrated Security=True";
            return DbString;
        }
    }
}
